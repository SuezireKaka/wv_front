import Register from "login/Register";
import LoginStage from "login/LoginStage";
export default function Home() {

  return (
    <div>
      <p class="border border-danger-subtle">
      
      기본화면띄울 곳.</p>
    </div>
  )
}
