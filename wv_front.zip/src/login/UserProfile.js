export default function UserProfile({user = {}}){
    return <p>프로필 준비중</p>
}